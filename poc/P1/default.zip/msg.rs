use cosmwasm_schema::cw_serde;

#[cw_serde]
pub enum QueryMsg {
    GetCallCount {},
}

#[cw_serde]
pub struct CallCountResponse {
    pub count: u64,
}

#[cw_serde]
pub struct InstantiateMsg {}

#[cw_serde]
pub struct Delegation {
    pub validator_address: String,
    pub delegator_address: String,
    pub shares: String,
}

#[cw_serde]
pub enum SudoMsg {
    #[serde(rename = "before_delegation_shares_modified")]
    BeforeDelegationSharesModified(Delegation),
    //AfterDelegationModified
    #[serde(rename = "after_delegation_modified")]
    AfterDelegationModified(Delegation),
}
