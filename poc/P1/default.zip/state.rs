use cosmwasm_std::Addr;
use cw_storage_plus::Item;

pub const CREATOR: Item<Addr> = Item::new("creator");

pub const CALL_COUNT: Item<u64> = Item::new("call_count");

pub const MAX_COUNT: Item<u64> = Item::new("max_count");
