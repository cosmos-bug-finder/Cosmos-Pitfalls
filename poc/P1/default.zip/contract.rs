#[cfg(not(feature = "library"))]
use cosmwasm_std::entry_point;
use cosmwasm_std::to_binary;
use cosmwasm_std::{BankMsg, StakingMsg};
use cosmwasm_std::{
    Binary, Coin, CosmosMsg, Deps, DepsMut, Env, MessageInfo, ReplyOn, Response, StdResult, SubMsg,
    Uint128,
};
use cw2::set_contract_version;

use crate::error::ContractError;
use crate::msg::{CallCountResponse, InstantiateMsg, QueryMsg, SudoMsg};
use crate::state::{CALL_COUNT,MAX_COUNT, CREATOR};
use cosmwasm_std::Reply;

// version info for migration info
const CONTRACT_NAME: &str = "crates.io:infinite-track-delegation-hook";
const CONTRACT_VERSION: &str = env!("CARGO_PKG_VERSION");

/// Handling contract instantiation
#[cfg_attr(not(feature = "library"), entry_point)]
pub fn instantiate(
    deps: DepsMut,
    _env: Env,
    info: MessageInfo,
    _msg: InstantiateMsg,
) -> Result<Response, ContractError> {
    set_contract_version(deps.storage, CONTRACT_NAME, CONTRACT_VERSION)?;
    CREATOR.save(deps.storage, &info.sender)?;
    MAX_COUNT.save(deps.storage, &1)?;
    Ok(Response::new()
        .add_attribute("method", "instantiate")
        .add_attribute("creator", info.sender))
}

#[cfg_attr(not(feature = "library"), entry_point)]
pub fn sudo(deps: DepsMut, _env: Env, msg: SudoMsg) -> Result<Response, ContractError> {
    match msg {
        SudoMsg::AfterDelegationModified(del) => {
            let delegate_amount = Coin {
                denom: "ujuno".to_string(),
                amount: Uint128::new(1),
            };
            let cosmos_msg1 = CosmosMsg::Staking(StakingMsg::Delegate {
                validator: del.validator_address.clone(),
                amount: delegate_amount.clone(),
            });
            Ok(Response::new().add_message(cosmos_msg1.clone()).add_message(cosmos_msg1.clone()))
        }
        SudoMsg::BeforeDelegationSharesModified(del) => {
            let mut resp = Response::new();
            Ok(resp)
        }
    }
}